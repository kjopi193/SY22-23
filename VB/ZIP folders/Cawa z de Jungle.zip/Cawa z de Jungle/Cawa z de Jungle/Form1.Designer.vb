﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Box = New System.Windows.Forms.PictureBox()
        Me.Total_Price_TextBox = New System.Windows.Forms.TextBox()
        Me.Pounds_TextBox = New System.Windows.Forms.TextBox()
        Me.ZIP_TextBox = New System.Windows.Forms.TextBox()
        Me.Regular_TextBox = New System.Windows.Forms.TextBox()
        Me.Decaf_TextBox = New System.Windows.Forms.TextBox()
        Me.State_TextBox = New System.Windows.Forms.TextBox()
        Me.Name_TextBox = New System.Windows.Forms.TextBox()
        Me.Adress_TextBox = New System.Windows.Forms.TextBox()
        Me.City_TextBox = New System.Windows.Forms.TextBox()
        Me.Exit_Button = New System.Windows.Forms.Button()
        Me.Cancle_Button = New System.Windows.Forms.Button()
        Me.Print_Button = New System.Windows.Forms.Button()
        Me.Cauculate_Button = New System.Windows.Forms.Button()
        Me.Toatal_Price_Label = New System.Windows.Forms.Label()
        Me.Pounds_Orderd_Label = New System.Windows.Forms.Label()
        Me.Decaf_Label = New System.Windows.Forms.Label()
        Me.Regular_Label = New System.Windows.Forms.Label()
        Me.ZIP_Label = New System.Windows.Forms.Label()
        Me.State_Label = New System.Windows.Forms.Label()
        Me.City_Label = New System.Windows.Forms.Label()
        Me.Adress_Label = New System.Windows.Forms.Label()
        Me.Name_Label = New System.Windows.Forms.Label()
        Me.Order_Form_Label = New System.Windows.Forms.Label()
        Me.Eror_Mesage_Label = New System.Windows.Forms.Label()
        Me.Printer_Fail_Label = New System.Windows.Forms.Label()
        CType(Me.Box, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Box
        '
        Me.Box.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Box.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Box.Location = New System.Drawing.Point(12, 12)
        Me.Box.Name = "Box"
        Me.Box.Size = New System.Drawing.Size(658, 386)
        Me.Box.TabIndex = 23
        Me.Box.TabStop = False
        '
        'Total_Price_TextBox
        '
        Me.Total_Price_TextBox.Location = New System.Drawing.Point(464, 193)
        Me.Total_Price_TextBox.Name = "Total_Price_TextBox"
        Me.Total_Price_TextBox.Size = New System.Drawing.Size(95, 22)
        Me.Total_Price_TextBox.TabIndex = 46
        '
        'Pounds_TextBox
        '
        Me.Pounds_TextBox.Location = New System.Drawing.Point(464, 79)
        Me.Pounds_TextBox.Name = "Pounds_TextBox"
        Me.Pounds_TextBox.Size = New System.Drawing.Size(95, 22)
        Me.Pounds_TextBox.TabIndex = 45
        '
        'ZIP_TextBox
        '
        Me.ZIP_TextBox.Location = New System.Drawing.Point(138, 345)
        Me.ZIP_TextBox.Name = "ZIP_TextBox"
        Me.ZIP_TextBox.Size = New System.Drawing.Size(74, 22)
        Me.ZIP_TextBox.TabIndex = 44
        '
        'Regular_TextBox
        '
        Me.Regular_TextBox.Location = New System.Drawing.Point(261, 345)
        Me.Regular_TextBox.Name = "Regular_TextBox"
        Me.Regular_TextBox.Size = New System.Drawing.Size(74, 22)
        Me.Regular_TextBox.TabIndex = 43
        '
        'Decaf_TextBox
        '
        Me.Decaf_TextBox.Location = New System.Drawing.Point(372, 345)
        Me.Decaf_TextBox.Name = "Decaf_TextBox"
        Me.Decaf_TextBox.Size = New System.Drawing.Size(74, 22)
        Me.Decaf_TextBox.TabIndex = 42
        '
        'State_TextBox
        '
        Me.State_TextBox.Location = New System.Drawing.Point(36, 345)
        Me.State_TextBox.Name = "State_TextBox"
        Me.State_TextBox.Size = New System.Drawing.Size(74, 22)
        Me.State_TextBox.TabIndex = 41
        '
        'Name_TextBox
        '
        Me.Name_TextBox.Location = New System.Drawing.Point(36, 80)
        Me.Name_TextBox.Name = "Name_TextBox"
        Me.Name_TextBox.Size = New System.Drawing.Size(406, 22)
        Me.Name_TextBox.TabIndex = 40
        '
        'Adress_TextBox
        '
        Me.Adress_TextBox.Location = New System.Drawing.Point(36, 175)
        Me.Adress_TextBox.Name = "Adress_TextBox"
        Me.Adress_TextBox.Size = New System.Drawing.Size(406, 22)
        Me.Adress_TextBox.TabIndex = 39
        '
        'City_TextBox
        '
        Me.City_TextBox.Location = New System.Drawing.Point(36, 258)
        Me.City_TextBox.Name = "City_TextBox"
        Me.City_TextBox.Size = New System.Drawing.Size(406, 22)
        Me.City_TextBox.TabIndex = 38
        '
        'Exit_Button
        '
        Me.Exit_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exit_Button.Location = New System.Drawing.Point(464, 344)
        Me.Exit_Button.Name = "Exit_Button"
        Me.Exit_Button.Size = New System.Drawing.Size(177, 28)
        Me.Exit_Button.TabIndex = 37
        Me.Exit_Button.Text = "&Exit Shop"
        Me.Exit_Button.UseVisualStyleBackColor = True
        '
        'Cancle_Button
        '
        Me.Cancle_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancle_Button.Location = New System.Drawing.Point(464, 314)
        Me.Cancle_Button.Name = "Cancle_Button"
        Me.Cancle_Button.Size = New System.Drawing.Size(177, 28)
        Me.Cancle_Button.TabIndex = 36
        Me.Cancle_Button.Text = "&Cancle Order"
        Me.Cancle_Button.UseVisualStyleBackColor = True
        '
        'Print_Button
        '
        Me.Print_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Print_Button.Location = New System.Drawing.Point(464, 285)
        Me.Print_Button.Name = "Print_Button"
        Me.Print_Button.Size = New System.Drawing.Size(177, 28)
        Me.Print_Button.TabIndex = 35
        Me.Print_Button.Text = "&Print Order"
        Me.Print_Button.UseVisualStyleBackColor = True
        '
        'Cauculate_Button
        '
        Me.Cauculate_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cauculate_Button.Location = New System.Drawing.Point(464, 255)
        Me.Cauculate_Button.Name = "Cauculate_Button"
        Me.Cauculate_Button.Size = New System.Drawing.Size(177, 28)
        Me.Cauculate_Button.TabIndex = 34
        Me.Cauculate_Button.Text = "&Cauculate Order"
        Me.Cauculate_Button.UseVisualStyleBackColor = True
        '
        'Toatal_Price_Label
        '
        Me.Toatal_Price_Label.AutoSize = True
        Me.Toatal_Price_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Toatal_Price_Label.Location = New System.Drawing.Point(473, 174)
        Me.Toatal_Price_Label.Name = "Toatal_Price_Label"
        Me.Toatal_Price_Label.Size = New System.Drawing.Size(74, 18)
        Me.Toatal_Price_Label.TabIndex = 33
        Me.Toatal_Price_Label.Text = "&Total Price"
        '
        'Pounds_Orderd_Label
        '
        Me.Pounds_Orderd_Label.AutoSize = True
        Me.Pounds_Orderd_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pounds_Orderd_Label.Location = New System.Drawing.Point(473, 60)
        Me.Pounds_Orderd_Label.Name = "Pounds_Orderd_Label"
        Me.Pounds_Orderd_Label.Size = New System.Drawing.Size(100, 18)
        Me.Pounds_Orderd_Label.TabIndex = 32
        Me.Pounds_Orderd_Label.Text = "&Pounds Orderd"
        '
        'Decaf_Label
        '
        Me.Decaf_Label.AutoSize = True
        Me.Decaf_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Decaf_Label.Location = New System.Drawing.Point(388, 327)
        Me.Decaf_Label.Name = "Decaf_Label"
        Me.Decaf_Label.Size = New System.Drawing.Size(45, 18)
        Me.Decaf_Label.TabIndex = 31
        Me.Decaf_Label.Text = "&Decaf"
        '
        'Regular_Label
        '
        Me.Regular_Label.AutoSize = True
        Me.Regular_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Regular_Label.Location = New System.Drawing.Point(272, 327)
        Me.Regular_Label.Name = "Regular_Label"
        Me.Regular_Label.Size = New System.Drawing.Size(57, 18)
        Me.Regular_Label.TabIndex = 30
        Me.Regular_Label.Text = "&Regular"
        '
        'ZIP_Label
        '
        Me.ZIP_Label.AutoSize = True
        Me.ZIP_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ZIP_Label.Location = New System.Drawing.Point(164, 326)
        Me.ZIP_Label.Name = "ZIP_Label"
        Me.ZIP_Label.Size = New System.Drawing.Size(29, 18)
        Me.ZIP_Label.TabIndex = 29
        Me.ZIP_Label.Text = "&ZIP"
        '
        'State_Label
        '
        Me.State_Label.AutoSize = True
        Me.State_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.State_Label.Location = New System.Drawing.Point(55, 326)
        Me.State_Label.Name = "State_Label"
        Me.State_Label.Size = New System.Drawing.Size(40, 18)
        Me.State_Label.TabIndex = 28
        Me.State_Label.Text = "&State"
        '
        'City_Label
        '
        Me.City_Label.AutoSize = True
        Me.City_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.City_Label.Location = New System.Drawing.Point(44, 239)
        Me.City_Label.Name = "City_Label"
        Me.City_Label.Size = New System.Drawing.Size(31, 18)
        Me.City_Label.TabIndex = 27
        Me.City_Label.Text = "&City"
        '
        'Adress_Label
        '
        Me.Adress_Label.AutoSize = True
        Me.Adress_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Adress_Label.Location = New System.Drawing.Point(44, 156)
        Me.Adress_Label.Name = "Adress_Label"
        Me.Adress_Label.Size = New System.Drawing.Size(52, 18)
        Me.Adress_Label.TabIndex = 26
        Me.Adress_Label.Text = "&Adress"
        '
        'Name_Label
        '
        Me.Name_Label.AutoSize = True
        Me.Name_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Name_Label.Location = New System.Drawing.Point(44, 61)
        Me.Name_Label.Name = "Name_Label"
        Me.Name_Label.Size = New System.Drawing.Size(46, 18)
        Me.Name_Label.TabIndex = 25
        Me.Name_Label.Text = "&Name"
        '
        'Order_Form_Label
        '
        Me.Order_Form_Label.AutoSize = True
        Me.Order_Form_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Order_Form_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Order_Form_Label.Location = New System.Drawing.Point(137, 32)
        Me.Order_Form_Label.Name = "Order_Form_Label"
        Me.Order_Form_Label.Size = New System.Drawing.Size(251, 34)
        Me.Order_Form_Label.TabIndex = 24
        Me.Order_Form_Label.Text = "Coffe Order Form"
        '
        'Eror_Mesage_Label
        '
        Me.Eror_Mesage_Label.AutoSize = True
        Me.Eror_Mesage_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Eror_Mesage_Label.Font = New System.Drawing.Font("Agency FB", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Eror_Mesage_Label.Location = New System.Drawing.Point(887, 107)
        Me.Eror_Mesage_Label.Name = "Eror_Mesage_Label"
        Me.Eror_Mesage_Label.Size = New System.Drawing.Size(144, 38)
        Me.Eror_Mesage_Label.TabIndex = 47
        Me.Eror_Mesage_Label.Text = "EROR MESAGE"
        Me.Eror_Mesage_Label.Visible = False
        '
        'Printer_Fail_Label
        '
        Me.Printer_Fail_Label.AutoSize = True
        Me.Printer_Fail_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Printer_Fail_Label.Location = New System.Drawing.Point(828, 156)
        Me.Printer_Fail_Label.Name = "Printer_Fail_Label"
        Me.Printer_Fail_Label.Size = New System.Drawing.Size(259, 18)
        Me.Printer_Fail_Label.TabIndex = 48
        Me.Printer_Fail_Label.Text = "Printer Faild to print dew to paper shortage"
        Me.Printer_Fail_Label.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1262, 736)
        Me.Controls.Add(Me.Printer_Fail_Label)
        Me.Controls.Add(Me.Eror_Mesage_Label)
        Me.Controls.Add(Me.Total_Price_TextBox)
        Me.Controls.Add(Me.Pounds_TextBox)
        Me.Controls.Add(Me.ZIP_TextBox)
        Me.Controls.Add(Me.Regular_TextBox)
        Me.Controls.Add(Me.Decaf_TextBox)
        Me.Controls.Add(Me.State_TextBox)
        Me.Controls.Add(Me.Name_TextBox)
        Me.Controls.Add(Me.Adress_TextBox)
        Me.Controls.Add(Me.City_TextBox)
        Me.Controls.Add(Me.Exit_Button)
        Me.Controls.Add(Me.Cancle_Button)
        Me.Controls.Add(Me.Print_Button)
        Me.Controls.Add(Me.Cauculate_Button)
        Me.Controls.Add(Me.Toatal_Price_Label)
        Me.Controls.Add(Me.Pounds_Orderd_Label)
        Me.Controls.Add(Me.Decaf_Label)
        Me.Controls.Add(Me.Regular_Label)
        Me.Controls.Add(Me.ZIP_Label)
        Me.Controls.Add(Me.State_Label)
        Me.Controls.Add(Me.City_Label)
        Me.Controls.Add(Me.Adress_Label)
        Me.Controls.Add(Me.Name_Label)
        Me.Controls.Add(Me.Order_Form_Label)
        Me.Controls.Add(Me.Box)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Box, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Box As PictureBox
    Friend WithEvents Total_Price_TextBox As TextBox
    Friend WithEvents Pounds_TextBox As TextBox
    Friend WithEvents ZIP_TextBox As TextBox
    Friend WithEvents Regular_TextBox As TextBox
    Friend WithEvents Decaf_TextBox As TextBox
    Friend WithEvents State_TextBox As TextBox
    Friend WithEvents Name_TextBox As TextBox
    Friend WithEvents Adress_TextBox As TextBox
    Friend WithEvents City_TextBox As TextBox
    Friend WithEvents Exit_Button As Button
    Friend WithEvents Cancle_Button As Button
    Friend WithEvents Print_Button As Button
    Friend WithEvents Cauculate_Button As Button
    Friend WithEvents Toatal_Price_Label As Label
    Friend WithEvents Pounds_Orderd_Label As Label
    Friend WithEvents Decaf_Label As Label
    Friend WithEvents Regular_Label As Label
    Friend WithEvents ZIP_Label As Label
    Friend WithEvents State_Label As Label
    Friend WithEvents City_Label As Label
    Friend WithEvents Adress_Label As Label
    Friend WithEvents Name_Label As Label
    Friend WithEvents Order_Form_Label As Label
    Friend WithEvents Eror_Mesage_Label As Label
    Friend WithEvents Printer_Fail_Label As Label
End Class
