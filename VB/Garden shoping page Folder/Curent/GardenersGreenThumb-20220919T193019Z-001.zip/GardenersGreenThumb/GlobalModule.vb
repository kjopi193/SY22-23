﻿Module GlobalModule



    Public NumbrOfTrees As Integer
    Public PriceOfTrees As Decimal

    Public NumberOfHerbs As Integer
    Public PriceOfHerbs As Decimal



    Public Texas_Mountain_Laurel_Price As Decimal
    Public Texas_Mountain_Laurel_Quantity As Integer
    Public Texas_Mountain_Laurel_Total_Price As Decimal
    Public Texas_Mountain_Laurel_Quantity_In_Cart As Integer
    Public Texas_Mountain_Laurel_Total_Price_In_Cart As Decimal

End Module
