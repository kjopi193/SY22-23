﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GardenersGreenThumbMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Texas_Mountain_Laurel_Button = New System.Windows.Forms.Button()
        Me.Eye_of_Africa_Flower_Button = New System.Windows.Forms.Button()
        Me.Eagle_fern_Button = New System.Windows.Forms.Button()
        Me.Trees_Label = New System.Windows.Forms.Label()
        Me.Flowers_Label = New System.Windows.Forms.Label()
        Me.Small_Plants_Label = New System.Windows.Forms.Label()
        Me.Gardeners_Green_Thumb_Label = New System.Windows.Forms.Label()
        Me.Texas_Mountain_Laurel_PictureBox = New System.Windows.Forms.PictureBox()
        Me.Eye_of_Africa_Flower_PictureBox = New System.Windows.Forms.PictureBox()
        Me.Eagle_Fern_PictureBox = New System.Windows.Forms.PictureBox()
        Me.Show_Caret_Button = New System.Windows.Forms.Button()
        CType(Me.Texas_Mountain_Laurel_PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Eye_of_Africa_Flower_PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Eagle_Fern_PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Texas_Mountain_Laurel_Button
        '
        Me.Texas_Mountain_Laurel_Button.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.Texas_Mountain_Laurel_Button.Location = New System.Drawing.Point(157, 300)
        Me.Texas_Mountain_Laurel_Button.Name = "Texas_Mountain_Laurel_Button"
        Me.Texas_Mountain_Laurel_Button.Size = New System.Drawing.Size(104, 48)
        Me.Texas_Mountain_Laurel_Button.TabIndex = 0
        Me.Texas_Mountain_Laurel_Button.Text = "Texas Mountain Laurel"
        Me.Texas_Mountain_Laurel_Button.UseVisualStyleBackColor = False
        '
        'Eye_of_Africa_Flower_Button
        '
        Me.Eye_of_Africa_Flower_Button.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.Eye_of_Africa_Flower_Button.Location = New System.Drawing.Point(626, 300)
        Me.Eye_of_Africa_Flower_Button.Name = "Eye_of_Africa_Flower_Button"
        Me.Eye_of_Africa_Flower_Button.Size = New System.Drawing.Size(100, 48)
        Me.Eye_of_Africa_Flower_Button.TabIndex = 1
        Me.Eye_of_Africa_Flower_Button.Text = "Eye of Africa Flower"
        Me.Eye_of_Africa_Flower_Button.UseVisualStyleBackColor = False
        '
        'Eagle_fern_Button
        '
        Me.Eagle_fern_Button.BackColor = System.Drawing.Color.MediumSeaGreen
        Me.Eagle_fern_Button.Location = New System.Drawing.Point(1082, 300)
        Me.Eagle_fern_Button.Name = "Eagle_fern_Button"
        Me.Eagle_fern_Button.Size = New System.Drawing.Size(106, 23)
        Me.Eagle_fern_Button.TabIndex = 3
        Me.Eagle_fern_Button.Text = "Eagle fern"
        Me.Eagle_fern_Button.UseVisualStyleBackColor = False
        '
        'Trees_Label
        '
        Me.Trees_Label.AutoSize = True
        Me.Trees_Label.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Trees_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Trees_Label.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Trees_Label.Location = New System.Drawing.Point(180, 149)
        Me.Trees_Label.Name = "Trees_Label"
        Me.Trees_Label.Size = New System.Drawing.Size(68, 26)
        Me.Trees_Label.TabIndex = 5
        Me.Trees_Label.Text = "Trees"
        '
        'Flowers_Label
        '
        Me.Flowers_Label.AutoSize = True
        Me.Flowers_Label.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Flowers_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Flowers_Label.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Flowers_Label.Location = New System.Drawing.Point(628, 149)
        Me.Flowers_Label.Name = "Flowers_Label"
        Me.Flowers_Label.Size = New System.Drawing.Size(90, 26)
        Me.Flowers_Label.TabIndex = 6
        Me.Flowers_Label.Text = "Flowers"
        '
        'Small_Plants_Label
        '
        Me.Small_Plants_Label.AutoSize = True
        Me.Small_Plants_Label.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Small_Plants_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Small_Plants_Label.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Small_Plants_Label.Location = New System.Drawing.Point(1064, 149)
        Me.Small_Plants_Label.Name = "Small_Plants_Label"
        Me.Small_Plants_Label.Size = New System.Drawing.Size(137, 26)
        Me.Small_Plants_Label.TabIndex = 7
        Me.Small_Plants_Label.Text = "Smal Plants "
        '
        'Gardeners_Green_Thumb_Label
        '
        Me.Gardeners_Green_Thumb_Label.AutoSize = True
        Me.Gardeners_Green_Thumb_Label.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Gardeners_Green_Thumb_Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Gardeners_Green_Thumb_Label.Font = New System.Drawing.Font("Lucida Calligraphy", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Gardeners_Green_Thumb_Label.Location = New System.Drawing.Point(460, 46)
        Me.Gardeners_Green_Thumb_Label.Name = "Gardeners_Green_Thumb_Label"
        Me.Gardeners_Green_Thumb_Label.Size = New System.Drawing.Size(417, 39)
        Me.Gardeners_Green_Thumb_Label.TabIndex = 8
        Me.Gardeners_Green_Thumb_Label.Text = "Gardeners Green Thumb"
        '
        'Texas_Mountain_Laurel_PictureBox
        '
        Me.Texas_Mountain_Laurel_PictureBox.Location = New System.Drawing.Point(161, 244)
        Me.Texas_Mountain_Laurel_PictureBox.Name = "Texas_Mountain_Laurel_PictureBox"
        Me.Texas_Mountain_Laurel_PictureBox.Size = New System.Drawing.Size(100, 50)
        Me.Texas_Mountain_Laurel_PictureBox.TabIndex = 9
        Me.Texas_Mountain_Laurel_PictureBox.TabStop = False
        '
        'Eye_of_Africa_Flower_PictureBox
        '
        Me.Eye_of_Africa_Flower_PictureBox.Location = New System.Drawing.Point(626, 244)
        Me.Eye_of_Africa_Flower_PictureBox.Name = "Eye_of_Africa_Flower_PictureBox"
        Me.Eye_of_Africa_Flower_PictureBox.Size = New System.Drawing.Size(100, 50)
        Me.Eye_of_Africa_Flower_PictureBox.TabIndex = 10
        Me.Eye_of_Africa_Flower_PictureBox.TabStop = False
        '
        'Eagle_Fern_PictureBox
        '
        Me.Eagle_Fern_PictureBox.Location = New System.Drawing.Point(1084, 244)
        Me.Eagle_Fern_PictureBox.Name = "Eagle_Fern_PictureBox"
        Me.Eagle_Fern_PictureBox.Size = New System.Drawing.Size(100, 50)
        Me.Eagle_Fern_PictureBox.TabIndex = 11
        Me.Eagle_Fern_PictureBox.TabStop = False
        '
        'Show_Caret_Button
        '
        Me.Show_Caret_Button.Location = New System.Drawing.Point(653, 489)
        Me.Show_Caret_Button.Name = "Show_Caret_Button"
        Me.Show_Caret_Button.Size = New System.Drawing.Size(75, 23)
        Me.Show_Caret_Button.TabIndex = 12
        Me.Show_Caret_Button.Text = "Show Cart"
        Me.Show_Caret_Button.UseVisualStyleBackColor = True
        '
        'GardenersGreenThumbMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(1335, 814)
        Me.Controls.Add(Me.Show_Caret_Button)
        Me.Controls.Add(Me.Eagle_Fern_PictureBox)
        Me.Controls.Add(Me.Eye_of_Africa_Flower_PictureBox)
        Me.Controls.Add(Me.Texas_Mountain_Laurel_PictureBox)
        Me.Controls.Add(Me.Gardeners_Green_Thumb_Label)
        Me.Controls.Add(Me.Small_Plants_Label)
        Me.Controls.Add(Me.Flowers_Label)
        Me.Controls.Add(Me.Trees_Label)
        Me.Controls.Add(Me.Eagle_fern_Button)
        Me.Controls.Add(Me.Eye_of_Africa_Flower_Button)
        Me.Controls.Add(Me.Texas_Mountain_Laurel_Button)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Name = "GardenersGreenThumbMain"
        Me.Text = "Gardeners Green Thumb"
        CType(Me.Texas_Mountain_Laurel_PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Eye_of_Africa_Flower_PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Eagle_Fern_PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Texas_Mountain_Laurel_Button As Button
    Friend WithEvents Eye_of_Africa_Flower_Button As Button
    Friend WithEvents Eagle_fern_Button As Button
    Friend WithEvents Trees_Label As Label
    Friend WithEvents Flowers_Label As Label
    Friend WithEvents Small_Plants_Label As Label
    Friend WithEvents Gardeners_Green_Thumb_Label As Label
    Friend WithEvents Texas_Mountain_Laurel_PictureBox As PictureBox
    Friend WithEvents Eye_of_Africa_Flower_PictureBox As PictureBox
    Friend WithEvents Eagle_Fern_PictureBox As PictureBox
    Friend WithEvents Show_Caret_Button As Button
End Class
