﻿Public Class Eagle_fern_Form
    Private Sub Plant_Info_Box_Click(sender As Object, e As EventArgs) Handles Plant_Info_Box.Click

    End Sub

    Private Sub Eagle_fern_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class